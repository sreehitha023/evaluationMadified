package com.msil.newuser.controller;



import com.msil.newuser.entity.NewUserEntity;
import com.msil.newuser.service.NewUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/user")
public class NewUserController {
    @Autowired
    NewUserService newUserService;
    @GetMapping
    public List<NewUserEntity> findAllUsers()
    {
        return newUserService.findAllUsers();
    }
    @GetMapping("/{id}")
    public Optional<NewUserEntity> findById(@PathVariable("id") Long id)
    {
        return newUserService.findById(id);
    }
    @PostMapping("/save")
    public NewUserEntity saveUser(@RequestBody NewUserEntity newUserEntity)
    {
        return newUserService.saveUser(newUserEntity);
    }
    @PostMapping
    public NewUserEntity updateUser(@RequestBody NewUserEntity newUserEntity)
    {
    return newUserService.updateUser(newUserEntity);
    }
    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable("id") Long id)
    {
        newUserService.deleteUser(id);
        return "success";
    }

}

