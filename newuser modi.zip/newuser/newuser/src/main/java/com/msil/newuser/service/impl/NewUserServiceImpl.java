package com.msil.newuser.service.impl;

import com.msil.newuser.entity.NewUserEntity;
import com.msil.newuser.repository.NewUserRepository;
import com.msil.newuser.service.NewUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NewUserServiceImpl implements NewUserService {
    @Autowired
    NewUserRepository newUserRepository;

    @Override
    public List<NewUserEntity> findAllUsers() {
        return newUserRepository.findAll();
    }

    @Override
    public Optional<NewUserEntity> findById(Long id) {
        return newUserRepository.findById(id);
    }

    @Override
    public NewUserEntity saveUser(NewUserEntity newUserEntity) {
        return newUserRepository.save(newUserEntity);
    }

    @Override
    public NewUserEntity updateUser(NewUserEntity newUserEntity) {
        return newUserRepository.save(newUserEntity);
    }

    @Override
    public void deleteUser(Long id) {
        newUserRepository.deleteById(id);
    }

}

