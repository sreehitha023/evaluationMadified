package com.msil.newuser.service;

import com.msil.newuser.entity.NewUserEntity;

import java.util.List;
import java.util.Optional;

public interface NewUserService {

    List<NewUserEntity> findAllUsers();
    Optional<NewUserEntity> findById(Long id);
    NewUserEntity saveUser(NewUserEntity newUserEntity);
    NewUserEntity updateUser(NewUserEntity newUserEntity);
    void deleteUser(Long id);

}
