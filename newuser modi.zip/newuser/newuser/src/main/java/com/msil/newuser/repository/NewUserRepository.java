package com.msil.newuser.repository;

import com.msil.newuser.NewuserApplication;
import com.msil.newuser.entity.NewUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface NewUserRepository extends JpaRepository<NewUserEntity,Long> {

}
