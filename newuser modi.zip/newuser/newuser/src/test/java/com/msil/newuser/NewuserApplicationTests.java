package com.msil.newuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
