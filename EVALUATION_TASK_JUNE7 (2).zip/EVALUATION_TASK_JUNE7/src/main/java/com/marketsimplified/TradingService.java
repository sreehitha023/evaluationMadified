package com.marketsimplified;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

public class TradingService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger log = LogManager.getLogger();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonobject = new JSONObject();
		Connection connection = null;
		connection = Database.connect();
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null) {
			jb.append(line);
		}
		
		JSONObject jsonobj = new JSONObject(jb.toString());
		String symbol = jsonobj.getString("symbol");
		int price = jsonobj.getInt("price");
		int quantity = jsonobj.getInt("quantity");
		if (quantity < 0) {
			jsonobject.put("error", "quantity must be positive");
			jsonArray.put(jsonobject);
			out.print(jsonArray);
			return;
		}

		try {
			
			/* Retrieve stop_limit data for the symbol from the database
			 * 
			 */
			StopLimitData stopLimitData = Service.getStopLimitData(connection, symbol);

			if (stopLimitData != null) {
				int stopPrice = stopLimitData.getStopPrice();
				int limitPrice = stopLimitData.getLimitPrice();
				int tradedQty = stopLimitData.getTradedQty();

				/*tradedqty is 0 and price equal to stop price  first purchase done and trade started
				 * 
				 */
				int databasetradeqty = Service.getTradeQuantityInDatabase(connection, symbol);
				if (databasetradeqty == 0 && price == stopPrice) {
					jsonArray = Reuse.calculate(tradedQty, stopPrice, limitPrice, quantity, connection, symbol);
					out.print(jsonArray);
					
					/* if tradedqty is 0 and price not equal to stop price
					 * 
					 */
					
				} else if (!(price == stopPrice) && databasetradeqty == 0) {
					jsonobject.put("error", "First purchase price should be equal to stopprice");
					jsonArray.put(jsonobject);
					out.print(jsonArray);
					/* trade started next purchase started
					 * 
					 */
				} else if (databasetradeqty > 0) {

					if (price >= 200 && price <= 215) {
						jsonArray = Reuse.calculate(tradedQty, stopPrice, limitPrice, quantity, connection, symbol);
						out.print(jsonArray);
					} else {
						jsonobject.put("error", "Range exceeded");
						jsonArray.put(jsonobject);
						out.print(jsonArray);
					}
				}

			}
		} catch (Exception e) {
			jsonobject.put("error", "Invalid JSON format");
			jsonArray.put(jsonobject);
			out.print(jsonArray);
		} finally {
			Database.close(connection);
		}
	}
}
