package com.marketsimplified;

import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import org.json.JSONArray;
import org.json.JSONObject;

public class Reuse {

	public static JSONArray calculate(int tradedQty, int price, int limitPrice, int quantity, Connection connection,
			String symbol) throws ServletException, IOException {
		// Calculate the remaining quantity to be bought
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonobject = new JSONObject();
		int remainingQty = 50 - tradedQty;
		if (remainingQty > 0) {

			// Check if the price exceeds the limit price
			if (price <= limitPrice) {

				// Perform the purchase
				int purchaseQty = Math.min(quantity, remainingQty);
				Service.updateTradedQty(connection, symbol, tradedQty + purchaseQty);
				Service.insertPurchaseHistory(connection, symbol, price, purchaseQty);

				// Check if all orders are filled
				if (tradedQty + purchaseQty == 50) {
					jsonobject.put("message", "All orders filled");
					jsonArray.put(jsonobject);
					return jsonArray;
				} else {
					jsonobject.put("message", "Purchase successful");
					jsonArray.put(jsonobject);
					return jsonArray;
				}
			} else {
				jsonobject.put("message", "Price exceeds the limit. Purchase not allowed.");
				jsonArray.put(jsonobject);
				return jsonArray;
			}
		} else {
			jsonobject.put("message", "All orders are filled");
			jsonArray.put(jsonobject);
			return jsonArray;
		}

	}

}
