package com.marketsimplified;

public class StopLimitData {
		   String symbol;
		    int quantity;
		    int stopPrice;
		    int limitPrice; 
		    String action;
		    int tradedQty;

		    public String getSymbol() {
		        return symbol;
		    }

		    public void setSymbol(String symbol) {
		        this.symbol = symbol;
		    }

		    public int getQuantity() {
		        return quantity;
		    }

		    public void setQuantity(int quantity) {
		        this.quantity = quantity;
		    }

		    public int getStopPrice() {
		        return stopPrice;
		    }

		    public void setStopPrice(int stopPrice) {
		        this.stopPrice = stopPrice;
		    }

		    public int getLimitPrice() {
		        return limitPrice;
		    }

		    public void setLimitPrice(int limitPrice) {
		        this.limitPrice = limitPrice;
		    }

		    public String getAction() {
		        return action;
		    }

		    public void setAction(String action) {
		        this.action = action;
		    }

		    public int getTradedQty() {
		        return tradedQty;
		    }

		    public void setTradedQty(int tradedQty) {
		        this.tradedQty = tradedQty;
		    }

		    public StopLimitData(String symbol, int quantity, int stopPrice, int limitPrice, String action, int tradedQty) {
		        this.symbol = symbol;
		        this.quantity = quantity;
		        this.stopPrice = stopPrice;
		        this.limitPrice = limitPrice;
		        this.action = action;
		        this.tradedQty = tradedQty;
		    }
		}

