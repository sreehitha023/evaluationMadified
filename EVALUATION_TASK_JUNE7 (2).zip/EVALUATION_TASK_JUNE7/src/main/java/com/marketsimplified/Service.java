package com.marketsimplified;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;

public class Service {

	/*
	 * retriving the data from STOP_LIMIT table
	 */
	public static StopLimitData getStopLimitData(Connection connection, String symbol) throws ServletException {
		String query = "SELECT * FROM stop_limit WHERE symbol = ?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, symbol);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				int quantity = resultSet.getInt("quantity");
				int stopPrice = resultSet.getInt("stopPrice");
				int limitPrice = resultSet.getInt("limitPrice");
				String action = resultSet.getString("action");
				int tradedQty = resultSet.getInt("tradedQty");

				return new StopLimitData(symbol, quantity, stopPrice, limitPrice, action, tradedQty);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static void updateTradedQty(Connection connection, String symbol, int tradedQty) {
		String query = "UPDATE stop_limit SET tradedQty = ? WHERE symbol = ?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, tradedQty);
			statement.setString(2, symbol);
			statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void insertPurchaseHistory(Connection connection, String symbol, int price, int quantity) {
		String query = "INSERT INTO purchase_history (Symbol, Price, Quantity) VALUES (?, ?, ?)";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, symbol);
			statement.setInt(2, price);
			statement.setInt(3, quantity);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();

		}

	}

	public static int getTradeQuantityInDatabase(Connection connection, String symbol) {
		// TODO Auto-generated method stub
		String query = "SELECT tradedQty from STOP_LIMIT where symbol=?";

		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, symbol);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {

				int tradedQty = resultSet.getInt("tradedQty");

				return tradedQty;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}
